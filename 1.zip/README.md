# kiwoom_telegram
VS2022 python 이용
조건검색 결과를 텔레그램으로 전송.

![](./images/run-1.png)
![](./images/run-2.png)
![](./images/run-3.png)
![](./images/run-4.png)
![](./images/run-5.png)
![](./images/run-6.png)
